

int function(void)
{
        int i = 1;
        int n = 0;

        for(i = 1; i != n; ++i){
                x -= f(x) / dfdx(x);
        }
    return 0;
}

int main(void)
{
        return 0;
}
