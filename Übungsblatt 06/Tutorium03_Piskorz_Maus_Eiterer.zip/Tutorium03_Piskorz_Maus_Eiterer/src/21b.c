#include <stdio.h>
#include <math.h>

int main(void)
{

	int x, k, n, m;
	double a;
	a = 6.1;
	/*1.*/
	x = 5;
	k = 1;
	printf("%i\n", (x > (2 << (k - 1))));


	/*2.*/
	m = 2;
	n = 8;
	printf("%i\n", (n % m) == 0);

	/*3.*/
	printf("%f\n", floor(ceil(a)));

	return 0;
}
